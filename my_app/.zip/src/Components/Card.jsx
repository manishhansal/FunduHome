import React from 'react'
import imageFolder3 from "../imageFolder/mobile.jpeg";
import imageFolder1 from "../imageFolder/img2.jpeg";
import imageFolder2 from "../imageFolder/img3.jpeg";

export const Card = () => {
  return (
    <div className='ca1'>
        <div class="card-deck">
  <div class="card">
    <img  src={imageFolder1} class="card-img-top" alt="..."/>
    <div class="card-body">
    <div className="box1t">
              <h2 className="h2help">Helping you clean</h2>
              <p className="h2help">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Labore
                velit quis mollitia, optio recusandae nam accusantium hic,
                expedita unde dicta perferendis voluptatum minima commodi,
                quidem similique culpa vero consequuntur explicabo?
              </p>
            </div>
    </div>
  </div>
  <div class="card">
    <img src={imageFolder3} class="card-img-top" alt="..."/>
    <div class="card-body">
    <div className="box1t">
            <h2 className="h2help">CROWDSOURSE YOUR WISDOM</h2>
              <p className="h2help">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Labore
                velit quis mollitia, optio recusandae nam accusantium hic,
                expedita unde dicta perferendis voluptatum minima commodi,
                quidem similique culpa vero consequuntur explicabo?
              </p>
            </div>
    </div>
  </div>
  <div class="card">
    <img src={imageFolder2} class="card-img-top" alt="..."/>
    <div class="card-body">
    <div className="box1t">
            <h2 className="h2help">ACCESSIBILTY ON YOUR FIMGERPRINTS</h2>
              <p className="h2help">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Labore
                velit quis mollitia, optio recusandae nam accusantium hic,
                expedita unde dicta perferendis voluptatum minima commodi,
                quidem similique culpa vero consequuntur explicabo?
              </p>
            </div>
    </div>
  </div>
</div>
    </div>
  )
}
export default Card;