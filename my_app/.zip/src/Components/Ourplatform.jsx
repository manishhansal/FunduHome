

import "./our.css";

import React from "react";
export const Ourplatform = () => {
 
  return (

      
  <div className='ourPltfm'>
        <div className="future1">
          <div className="f2">
            What You Should <span className="span1t">Know</span> About
          </div>
          <div className="f2">
            {" "}
            <span className="span1t">Our Platform </span>
          </div>
          <br></br>
         
          <div className='threediv'>
            <div>
              <h2 className='thdiv'>Getting Started</h2>
              <p className='p1'>what are smallest cases?</p>
              <p className='p1'>Free and Taxes</p>
              <p className='p1'>Can I buy smallcase as a SIP?</p>
              <p className='p1'>How to invest in smallcase?</p>
            </div>
            <div>
              <h2  className='thdiv'>Investing With smallcases</h2>
              <p className='p1'>Watchlist and Draft</p>
              <p className='p1'>Creating your own portfolio</p>
              <p className='p1'>Orders and History</p>
            </div>
            <div>
              <h2  className='thdiv'>Gaming & Events</h2>
              <p className='p1'>Do you get dividennds from smallacases?</p>
              <p className='p1'>Who manages smallcases?</p>
              <p className='p1'>what is reblancing?</p>
            </div>
</div>
</div>
</div>


          
   
 

     
  );
};
export default Ourplatform;

