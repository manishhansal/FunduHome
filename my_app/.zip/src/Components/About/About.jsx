

import "./About.css";


export const About = () => {
 
  return (

      <div className="mainDiv">
        <h1>About this Website</h1>
   
      </div>

     
  );
};
export default About;

