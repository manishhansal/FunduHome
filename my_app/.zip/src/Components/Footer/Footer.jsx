import React, { useContext } from "react";
import { ThemeContext } from "../../context/ThemeContext";
import "./Footer.css";

export const Footer = () => {
  
  return (

      <div className="inDiv">
  
          <h1>Footer</h1>
    </div>
  );
};
export default Footer;
