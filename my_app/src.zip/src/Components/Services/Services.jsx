
import "./Service.css"


export const Service = () => {
  
  return (

      <div className='ser'>
        <h1>Services</h1>
    </div>

  )
}
export default Service;