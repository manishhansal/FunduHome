
import React from "react";


export const product = () => {
  
  return (

      <div className='ser'>
        <h1>Product Page</h1>
    </div>

  )
}
export default product;