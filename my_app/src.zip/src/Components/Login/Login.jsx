
import React from "react";


export const Login= () => {
  
  return (

      <div className='ser'>
        <h1>Login</h1>
    </div>

  )
}
export default Login;